import java.util.function.Supplier;

public class Triangle {

	public int side_one, side_two, side_three;
	
	public Triangle(int i, int j, int k) {
		// TODO Auto-generated constructor stub
		side_one = i;
		side_two = j;
		side_three = k;
	}

	public Object typeOf() {
		// TODO Auto-generated method stub
		String equilateral = "Equilateral";
		String isosceles = "Isosceles";
		String scalene = "Scalene";
		String invalid = "Invalid";
		
		if(side_one == side_two && side_two == side_three) {
			return equilateral;
		}
		else if(side_one == side_two || side_two == side_three || side_one == side_three) {
			return isosceles;
		}
		else if(side_one > 0 && side_two > 0 && side_three > 0 && (side_one + side_two) > side_three && 
				(side_two + side_three) > side_one && (side_one + side_three) > side_two) {
			return scalene;
		}
		else {
			return invalid;
		}
	}
}
