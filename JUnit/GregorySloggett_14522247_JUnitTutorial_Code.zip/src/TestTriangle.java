import static org.junit.Assert.*;

import org.junit.jupiter.api.Test;

class TestTriangle {
	
	@Test
	public void testIfEquilateral() {
		Triangle t = new Triangle(1,1,1);
		assertEquals("Equilateral", t.typeOf());
	}
	
	@Test
	public void testIfIsosceles() {
		Triangle t = new Triangle(1,2,2);
		assertEquals("Isosceles", t.typeOf());
	}
	
	@Test
	public void testIfScalene() {
		Triangle t = new Triangle(4,2,3);
		assertEquals("Scalene", t.typeOf());
	}
	
	@Test
	public void testIfInvalid() {
		Triangle t = new Triangle(1,10,3);
		assertEquals("Invalid", t.typeOf());
	}
	
	
	

}
